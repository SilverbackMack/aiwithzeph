// Repurpose · the AI engine (version 4: structured output + YouTube + history + clear errors)
import Anthropic from '@anthropic-ai/sdk';
import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

const MODEL = 'claude-haiku-5-5';
const MAX_INPUT = 12000;          // characters sent to the model
const LIMITS = { perIpPerDay: 12, perDay: 60, perMonth: 300 };

const json = (body, status = 200) => Response.json(body, { status });

const SYSTEM = `You repurpose content for busy creators and small businesses.
You will get the text of one article, video transcript or set of notes.
Fill in the "repurpose" tool. Rules:
1. Use only facts that are in the content. Don't add numbers, names or claims that aren't there.
2. Plain text only. No markdown symbols like # or **, no emojis.
3. No placeholders: no [Your Name], no [Button], no links that aren't in the content.
4. Newsletter: a subject line under 60 characters and a body of 120 to 200 words, friendly, in short paragraphs, ending with one clear next step.
5. Summary: 2 to 3 sentences, under 70 words.
6. Action points: 4 to 6 things the reader can actually do next. Each starts with a verb and is under 20 words.
7. Write in the same language as the content.`;

const TOOL = {
  name: 'repurpose',
  description: 'Return the three repurposed formats.',
  input_schema: {
    type: 'object',
    properties: {
      title: { type: 'string', description: 'A short title for this content, under 8 words' },
      newsletter_subject: { type: 'string' },
      newsletter_body: { type: 'string' },
      summary: { type: 'string' },
      action_points: { type: 'array', items: { type: 'string' }, minItems: 4, maxItems: 6 },
    },
    required: ['title', 'newsletter_subject', 'newsletter_body', 'summary', 'action_points'],
  },
};

function htmlToText(html) {
  return html
    .replace(/<(script|style|noscript|svg|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&rsquo;/g, "'").replace(/&quot;/g, '"')
    .replace(/\s+/g, ' ').trim();
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36';
class Blocked extends Error {}

function youtubeId(link) {
  const m = link.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|live\/)|youtu\.be\/)([\w-]{11})/);
  return m ? m[1] : null;
}

async function youtubeText(id) {
  const res = await fetch(`https://www.youtube.com/watch?v=${id}&hl=en`, { headers: { 'user-agent': UA, 'accept-language': 'en-GB,en;q=0.9' }, redirect: 'manual', signal: AbortSignal.timeout(9000) });
  const html = res.status === 200 ? await res.text() : '';
  const tracks = html.match(/"captionTracks":(\[.*?\])/);
  if (!tracks) throw new Blocked(res.status === 200 ? 'no-captions' : `blocked-${res.status}`);
  const list = JSON.parse(tracks[1]);
  const track = list.find((t) => (t.languageCode || '').startsWith('en')) || list[0];
  const xml = await (await fetch(track.baseUrl.replace(/\\u0026/g, '&'), { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(9000) })).text();
  const text = htmlToText(xml.replace(/<\/text>/g, ' </text>'));
  if (text.length < 200) throw new Blocked('empty-captions');
  return text;
}

async function getText(link) {
  const id = youtubeId(link);
  if (id) return youtubeText(id);
  const res = await fetch(link, { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(9000) });
  if (!res.ok) throw new Error(`That page answered with an error (${res.status}).`);
  return htmlToText(await res.text());
}

async function checkLimits(store, ip) {
  const now = new Date(); const day = now.toISOString().slice(0, 10); const month = day.slice(0, 7);
  const ipHash = crypto.createHash('sha256').update(ip + 'repurpose').digest('hex').slice(0, 16);
  const [m, d, i] = await Promise.all([
    store.list({ prefix: `usage/${month}` }), store.list({ prefix: `usage/${day}/` }), store.list({ prefix: `ip/${day}/${ipHash}/` }),
  ]);
  if (m.blobs.length >= LIMITS.perMonth) return 'The demo has hit its monthly limit. Try again next month.';
  if (d.blobs.length >= LIMITS.perDay) return 'The demo has hit its daily limit. Try again tomorrow.';
  if (i.blobs.length >= LIMITS.perIpPerDay) return `You've used your ${LIMITS.perIpPerDay} free generations for today.`;
  return null;
}

// Only successful generations count towards the limits
async function recordUse(store, ip) {
  const day = new Date().toISOString().slice(0, 10);
  const ipHash = crypto.createHash('sha256').update(ip + 'repurpose').digest('hex').slice(0, 16);
  const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  await Promise.all([store.set(`usage/${day}/${id}`, '1'), store.set(`ip/${day}/${ipHash}/${id}`, '1')]);
}

export default async (req, context) => {
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  let body; try { body = await req.json(); } catch { return json({ error: 'Bad request' }, 400); }
  let { link = '', text = '', sessionId = '' } = body;
  const source = link ? link.trim().slice(0, 300) : 'Pasted text';

  try {
    if (link) text = await getText(link.trim());
  } catch (e) {
    if (e instanceof Blocked) return json({ error: "YouTube didn't let the app read this video's captions. Open the video on YouTube, click …more, then Show transcript, copy it, and paste it here.", switchTo: 'text', reason: e.message }, 422);
    return json({ error: `Couldn't read that link. ${e.message}` }, 422);
  }
  text = (text || '').trim();
  if (text.length < 200) return json({ error: 'Not enough text to work with (need at least 200 characters).' }, 422);
  const trimmed = text.length > MAX_INPUT;
  text = text.slice(0, MAX_INPUT);

  const store = getStore('repurpose');
  const limited = await checkLimits(store, context.ip || 'unknown');
  if (limited) return json({ error: limited }, 429);

  let msg;
  try {
  const anthropic = new Anthropic();
  msg = await anthropic.messages.create({
    model: MODEL,
    max_tokens: 2000,
    system: SYSTEM,
    tools: [TOOL],
    tool_choice: { type: 'tool', name: 'repurpose' },
    messages: [{ role: 'user', content: `Here is the content:\n\n${text}` }],
  });
  } catch (e) {
    console.error('AI call failed:', e.message);
    return json({ error: 'The AI is warming up or busy right now. Please try again in a minute.' }, 503);
  }
  if (msg.stop_reason === 'max_tokens') return json({ error: 'The AI ran out of room before finishing. Try a shorter piece of content.' }, 502);
  const out = msg.content.find((b) => b.type === 'tool_use')?.input;
  if (!out) return json({ error: 'The AI did not return the three formats. Please try again.' }, 502);
  await recordUse(store, context.ip || 'unknown');
  let saved = null;
  if (/^[0-9a-f-]{36}$/.test(sessionId)) {
    const createdAt = new Date().toISOString();
    saved = { id: `${(9999999999999 - Date.now()).toString().padStart(13, '0')}`, createdAt, source, result: out };
    await store.setJSON(`gen/${sessionId}/${saved.id}`, saved);
  }
  return json({ result: out, saved, model: MODEL, usage: msg.usage, inputChars: text.length, trimmed });
};

export const config = { path: '/api/generate' };
