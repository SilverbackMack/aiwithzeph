// Repurpose · past generations for one browser
import { getStore } from '@netlify/blobs';

export default async (req) => {
  const url = new URL(req.url);
  const session = url.searchParams.get('session') || '';
  if (!/^[0-9a-f-]{36}$/.test(session)) return Response.json({ error: 'Missing session' }, { status: 400 });
  const store = getStore({ name: 'repurpose', consistency: 'strong' });
  const prefix = `gen/${session}/`;
  if (req.method === 'DELETE') {
    const { blobs } = await store.list({ prefix });
    await Promise.all(blobs.map((b) => store.delete(b.key)));
    return Response.json({ deleted: blobs.length });
  }
  const { blobs } = await store.list({ prefix });
  const keys = blobs.map((b) => b.key).sort().slice(0, 20); // ids count down, so newest first
  const items = (await Promise.all(keys.map((k) => store.get(k, { type: 'json' })))).filter(Boolean);
  return Response.json({ items });
};

export const config = { path: '/api/history', method: ['GET', 'DELETE'] };
