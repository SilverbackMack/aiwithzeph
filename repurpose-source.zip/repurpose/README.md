# Repurpose: an AI content repurposer (built for an AI with Zeph video)

Paste a blog post link or text. Get a newsletter draft, a short summary and action points. Past results are saved per browser.

Live demo: https://zeph-repurposer.netlify.app

## What's inside
- public/ : the page (HTML, CSS, JavaScript). No framework.
- netlify/functions/generate.mjs : the AI engine. Reads the link, calls Claude Haiku through Netlify's AI Gateway, returns structured results, saves them.
- netlify/functions/history.mjs : lists or clears the saved results for one browser.
- Storage: Netlify Blobs (a simple key-value store that comes with every Netlify project).

## Put it on your own free Netlify account
1. Make a free account at netlify.com.
2. Easiest: ask an AI coding tool (Claude Code, Bolt, Lovable or Netlify's Agent Runners) "Deploy this folder to a new Netlify project". Or install the Netlify CLI and run `netlify deploy --prod` in this folder.
3. That's it. The AI Gateway gives the function its AI key automatically, so there's nothing to paste. The first minute after a new deploy, the AI may answer "warming up": just try again.

## Costs and limits (check before you share your link)
- AI calls use your Netlify credits. Claude Haiku is cheap (a generation used roughly 2,000 to 5,000 input tokens and about 700 output tokens), but every deploy and every visitor also uses credits.
- On Netlify's free plan (checked 21 Nov 2026) you get 300 credits a month and each production deploy costs 15. When credits run out, every site on that account can be paused until the next month. Use a separate free account for experiments.
- The demo caps usage: 12 generations per visitor per day, 60 per day in total, 300 per month. Change LIMITS in generate.mjs.
- YouTube usually blocks servers from reading captions, so the app asks people to paste the transcript instead.
- There is no login. History is tied to a random ID stored in each browser. For real users, add proper sign-in and a real database (for example Netlify Database).

See PROMPTS.md for every plain-English prompt used, in order, with what went wrong.
