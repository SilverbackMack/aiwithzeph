# Plain-English prompts given to the AI builder (Claude Code)

Times are UTC on Sat 21 Nov 2026.

## Prompt 1 · Frontend (16:29)
Build a web app called Repurpose. A clean, modern dark-mode page where someone pastes a YouTube link, a blog post link, or plain text, and clicks Generate. Show three result cards: an email newsletter draft, a short summary, and actionable bullet points. Each card gets a copy button. It must work on a phone. Don't wire up any AI yet.

## Prompt 2 · Visual tweak (16:30)
The input box is narrower than the three cards, so it looks off. Make it the same width as the cards, and tighten the space between the headline and the box.

## Prompt 3 · Connect the AI (16:31)
Now connect the AI. When someone clicks Generate, grab the text from the link (or use the pasted text), send it to an AI model, and fill the three cards: newsletter, summary, action points. Use Netlify's built-in AI Gateway so there's no API key to manage. Use a cheap, fast model, and cap usage so a public demo can't run up a bill.

### What went wrong with version 1 (tested live, 16:32)
- Blog link (aiwithzeph.com/elevenlabs): worked, but every card showed raw markdown (## and **), fake buttons like "[Try ElevenLabs →]", and the action points were cut off mid-sentence.
- Wikipedia article (Content marketing): the reply hit the 1,200-token limit. The summary stops mid-sentence and the Action points card came back empty.
- YouTube link: "Not enough text to work with". A YouTube page is almost all code, so there was nothing to read.
- The "action points" were really a summary list (What it does, Best for, Ethics), not things to do.

## Prompt 4 · Structured output (16:34)
The results are messy. Make the AI return clean structured data instead of chatty text: a newsletter (subject + body), a summary, and 4 to 6 action points. No markdown symbols, no placeholder buttons or [Your Name], no facts that aren't in the content. Action points must start with a verb. If the reply gets cut off, show an error instead of half an answer.

## Prompt 5 · YouTube (16:34)
YouTube links fail. Try to get the video's captions. If YouTube blocks it, tell the user plainly and switch them to Paste text, with how to copy a transcript from YouTube.

### Version 2 results (tested live, 16:36)
- Wikipedia: clean newsletter (153 words), summary, 5 action points starting with verbs. Checked one fact (Johnson & Johnson 1888 publication): it is in the article. Only the first 12,000 characters were used.
- YouTube: the server still couldn't get captions (YouTube served the page without them). The app now says so and switches to Paste text. Pasting the transcript of "Build Your First AI Agent in 10 Minutes" worked.
- Small slip: that newsletter was 216 words, over the 200-word rule. Word limits steer the AI; they aren't guaranteed.

## Prompt 6 · Database + history (16:37)
Save every generation in a cloud database, and show a "Past generations" sidebar so people can reopen old results. No sign-up: give each browser its own private ID. Add a button to clear your history.

### Version 3 first test (16:38, deploy published 16:37:34)
- Right after the deploy, both test generations failed with a server error: "Could not resolve authentication method". The AI Gateway's built-in key wasn't available to the function yet. About a minute later (16:39) the same kind of request worked.
- The app only showed "Something went wrong", and the failed tries still counted against the daily limit.

## Prompt 7 · Error handling (16:40)
When the AI call fails, show a clear message ("The AI is warming up or busy. Try again in a minute.") instead of "Something went wrong", log the real error, and don't count failed tries against anyone's limit.

### Version 4 test (16:40 to 16:41)
- Right after this deploy the AI Gateway hiccup happened again. This time the app showed "The AI is warming up or busy right now. Please try again in a minute." 25 seconds later it worked.
- Two generations saved to the database, but after reloading the page the Past generations sidebar was empty. Netlify Blobs lists are "eventually consistent": a new item can take up to 60 seconds to show up in a list.

## Prompt 8 · History consistency (16:42)
After a reload the history is empty even though the items were saved. Make the history always read the latest data.

### Final checks (16:43 to 16:45)
- After the fix, a reload showed both saved generations, and clicking the older one reopened it.
- A fresh "incognito" browser showed an empty history. That's by design: history is tied to each browser's private ID, because there is no login.
- A real generation from a second computer on a different network, in a phone-sized window (375 px wide), worked: "Newsletters: Their History and Modern Uses", saved at 16:43:42.
- On a phone, Netlify's free-plan "Powered by Netlify" badge covers part of the footer, and the history sits below the three cards.

## Prompt 9 · Share it (16:46)
Add a "Get the code" link so viewers can download the whole app and the prompts, with a short README on how to put it on their own free Netlify account. Give the footer room so the Netlify badge doesn't cover it on phones.
