// Repurpose · stage 3: AI + saved history
const $ = (s) => document.querySelector(s);
let mode = 'link';
// One private, random ID per browser. No sign-up, no email.
let sessionId = localStorage.getItem('repurpose-session');
if (!sessionId) { sessionId = crypto.randomUUID(); localStorage.setItem('repurpose-session', sessionId); }
let items = [];
document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach((x) => x.classList.remove('active'));
  t.classList.add('active'); mode = t.dataset.mode;
  $('#link').hidden = mode !== 'link'; $('#text').hidden = mode !== 'text';
}));
function status(msg, err) { const s = $('#status'); s.hidden = !msg; s.textContent = msg || ''; s.classList.toggle('err', !!err); }

const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function render(r) {
  $('#out-newsletter').innerHTML = `<p class="subj">${esc(r.newsletter_subject)}</p>` + r.newsletter_body.split(/\n+/).map((x) => `<p>${esc(x)}</p>`).join('');
  $('#out-summary').innerHTML = `<p>${esc(r.summary)}</p>`;
  $('#out-actions').innerHTML = '<ul>' + r.action_points.map((x) => `<li>${esc(x)}</li>`).join('') + '</ul>';
}
function setMode(m) { document.querySelector(`.tab[data-mode=${m}]`).click(); }

function when(iso) { const d = new Date(iso); return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ' · ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }); }
function short(src) { return src === 'Pasted text' ? 'Pasted text' : src.replace(/^https?:\/\/(www\.)?/, '').slice(0, 34); }
function drawHistory(activeId) {
  const h = $('#hist');
  if (!items.length) { h.innerHTML = '<p class="empty">Nothing yet. Your results are saved here, in this browser\'s private history.</p>'; return; }
  h.innerHTML = items.map((it) => `<button class="hi${it.id === activeId ? ' on' : ''}" data-id="${it.id}"><b>${esc(it.result.title)}</b><span>${esc(short(it.source))}</span><i>${when(it.createdAt)}</i></button>`).join('');
  h.querySelectorAll('.hi').forEach((b) => b.addEventListener('click', () => {
    const it = items.find((x) => x.id === b.dataset.id); render(it.result); drawHistory(it.id); status('Opened from your history.');
  }));
}
async function loadHistory() {
  try { const r = await fetch('/api/history?session=' + sessionId); items = (await r.json()).items || []; drawHistory(); } catch { /* history is optional */ }
}
$('#clear').addEventListener('click', async () => {
  await fetch('/api/history?session=' + sessionId, { method: 'DELETE' }); items = []; drawHistory(); status('History cleared.');
});
loadHistory();

$('#form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = mode === 'link' ? { link: $('#link').value.trim(), sessionId } : { text: $('#text').value, sessionId };
  $('#go').disabled = true; status('Reading and generating… (about 10 seconds)');
  try {
    const res = await fetch('/api/generate', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json().catch(() => ({ error: 'The server sent back an error (' + res.status + '). Please try again in a minute.' }));
    if (!res.ok) throw Object.assign(new Error(data.error || 'Something went wrong'), { switchTo: data.switchTo });
    render(data.result);
    if (data.saved) { items.unshift(data.saved); drawHistory(data.saved.id); }
    status(data.trimmed ? 'Done. (Long content: only the first part was used.)' : 'Done.');
  } catch (err) { status(err.message, true); if (err.switchTo) setMode(err.switchTo); }
  $('#go').disabled = false;
});
document.querySelectorAll('.copy').forEach((b) => b.addEventListener('click', () => {
  navigator.clipboard.writeText($('#out-' + b.dataset.copy).innerText); b.textContent = 'Copied'; setTimeout(() => (b.textContent = 'Copy'), 1200);
}));
